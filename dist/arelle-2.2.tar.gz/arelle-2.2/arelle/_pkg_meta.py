"""
Package version information module.
"""
version_info = (1, 0, 0) # Major, Minor, Fix
version = ".".join(map(str, version_info))
