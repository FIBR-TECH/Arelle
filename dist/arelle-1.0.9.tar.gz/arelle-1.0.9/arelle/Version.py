'''
This module represents the time stamp when Arelle was last built

@author: Mark V Systems Limited
(c) Copyright 2017 Mark V Systems Limited, All rights reserved.

'''
__version__ = '1.2017.10.07'  # number version of code base and date compiled
version = '2017-10-07 22:41 UTC'  # string version of date compiled
